# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| ALPHA   | :x: |

The project do not have securit for noww!

## Reporting a Vulnerability

Comment all vunerabilities that you find please!
 
✅
