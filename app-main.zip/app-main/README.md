# app V1
>[!IMPORTANT]
>This is the beta of the project, please suggest some addings that you'll like to see in the future!

The project has been created!!! :+1:
